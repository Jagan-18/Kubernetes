kubectl get po --no-headers | cut -d " " -f 1
for POD in $(kubectl get po --no-headers | cut -d " " -f 1); do
    kubectl exec -it $POD -- rm -rf /var/www/html/index.nginx-debian.html
    sleep 60
done


for POD in $(kubectl get po --no-headers | cut -d " " -f 1); do     kubectl exec -it $POD -- rm -rf /usr/share/nginx/html/index.html;     sleep 60; done &



===============By-Renaming-The-FIle===========
for POD in $(kubectl get po --no-headers | cut -d " " -f 1); do
    kubectl exec -it $POD -- mv /var/www/html/index.nginx-debian.html /usr/share/nginx/html/old
    sleep 5
done 

for POD in $(kubectl get po --no-headers | cut -d " " -f 1); do
    kubectl exec -it $POD -- mv /usr/share/nginx/html/old /var/www/html/index.nginx-debian.html
    sleep 5
done 
